const pageHeaderHTML = `
<div class="page-header shadow-sm">
  <h2 class="page-header-title">${headerTitle}</h2>
</div>
`;

document.getElementById('page-header').innerHTML = pageHeaderHTML;
