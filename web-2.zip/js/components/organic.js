const organic = `
<div
  style="position: absolute; right: 10%; top: 30%; left: 60%; z-index: -1"
>
  <svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
    <path
      fill="#BAE6FF"
      d="M22.5,-9.4C29,12.9,34.2,33.5,20.8,47.8C7.4,62,-24.5,69.9,-45,56.3C-65.5,42.8,-74.6,7.8,-65.2,-18.4C-55.7,-44.6,-27.9,-62,-10,-58.7C7.9,-55.5,15.9,-31.6,22.5,-9.4Z"
      transform="translate(100 100)"
    />
  </svg>
</div>`;

document.body.innerHTML += organic;
