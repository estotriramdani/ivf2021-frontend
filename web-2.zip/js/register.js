AOS.init();
console.log('1');
